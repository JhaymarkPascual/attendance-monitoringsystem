﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class mainform : Form
    {
        public mainform()
        {
            InitializeComponent();
        }

        private void mainform_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet3.Table213' table. You can move, or remove it, as needed.
            this.table213TableAdapter1.Fill(this.database1DataSet3.Table213);
            // TODO: This line of code loads data into the 'database1DataSet2.Table213' table. You can move, or remove it, as needed.
            this.table213TableAdapter.Fill(this.database1DataSet2.Table213);
            // TODO: This line of code loads data into the 'database1DataSet1.Attendancerecord' table. You can move, or remove it, as needed.
            this.attendancerecordTableAdapter.Fill(this.database1DataSet1.Attendancerecord);
     
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form meLoad = new Addclass();
            meLoad.Visible = true;
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form meLoad = new attendance();
            meLoad.Visible = true;
            this.Hide();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("confirm if you want to exit", "Inventory System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
