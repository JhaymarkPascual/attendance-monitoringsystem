﻿namespace WindowsFormsApplication1 {
    
    
    public partial class DataSet1 {
    }
}
