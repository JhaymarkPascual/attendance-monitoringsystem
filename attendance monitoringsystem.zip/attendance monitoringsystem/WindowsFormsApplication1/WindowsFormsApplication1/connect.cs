﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    class connect
    {
        public SqlConnection conn = new SqlConnection();
        public SqlCommand cmd = new SqlCommand();
        public string locate = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\jaymark\Desktop\attendance monitoringsystem\WindowsFormsApplication1\WindowsFormsApplication1\Database1.mdf;Integrated Security=True;Connect Timeout=30";
    }
}
