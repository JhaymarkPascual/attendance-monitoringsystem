﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class Loginform : Form
    {
        public Loginform()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignupForm.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
              if (usernameTxt.Text != null && passwordlogin.Text != null)
            {
                try
                {
                    connect obj = new connect();
                    obj.conn.ConnectionString = obj.locate;

                    obj.conn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter("SELECT COUNT (*)FROM Table5678 where username = '" + usernameTxt.Text + "' and password='" + passwordlogin.Text + "'", obj.conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        Form meLoad = new mainform();
                        meLoad.Visible = true;
                        this.Hide();
                        MessageBox.Show("Sucess");
                    }
                    else
                    {
                        MessageBox.Show("usernmae or password is incorrect");
                    }

                    obj.conn.Close();

                  
                }
                    catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("No empty fields are allowed");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             passwordNewTxt.PasswordChar = '*';
            passwordlogin.PasswordChar = '*';
            SignupForm.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
             if (usernameNewTxt != null && passwordNewTxt.Text != null)
            {
                try
                {
                    connect obj = new connect();
                    obj.conn.ConnectionString = obj.locate;
                    obj.conn.Open();
                    string insertuser = "insert into Table5678 values ('" + usernameNewTxt.Text + "','" + passwordNewTxt.Text + "')";
                    obj.cmd.Connection = obj.conn;
                    obj.cmd.CommandText = insertuser;
                    obj.cmd.ExecuteNonQuery();
                    obj.conn.Close();
                    MessageBox.Show("User Sign up has been completed");
                    SignupForm.Visible = false;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void SignupForm_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        }
        }

